package ru.oppodesk;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Рабочий стол на внешнем экране: обои, поиск и сетка приложений. */
public class DesktopActivity extends Activity {
    private final List<Apps.Entry> all = new ArrayList<>();
    private final List<Apps.Entry> shown = new ArrayList<>();
    private final Adapter adapter = new Adapter();

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] {0xFF0F2027, 0xFF203A43, 0xFF2C5364}));
        root.setPadding(dp(32), dp(24), dp(32), dp(56));

        EditText search = new EditText(this);
        search.setHint("Поиск приложений");
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(0x99FFFFFF);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(360),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.gravity = Gravity.CENTER_HORIZONTAL;
        sp.bottomMargin = dp(16);
        root.addView(search, sp);

        GridView grid = new GridView(this);
        grid.setColumnWidth(dp(104));
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(dp(12));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> open(shown.get(pos)));
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Display ext = DeskService.findExternal(getSystemService(DisplayManager.class));
        if (ext == null) {
            finish();
            return;
        }
        if (getDisplay().getDisplayId() == Display.DEFAULT_DISPLAY) {
            if (!Sh.ready()) {
                Toast.makeText(this, "Сначала запустите Shizuku и дайте OppoDesk разрешение",
                        Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            Sh.run("am display move-stack " + getTaskId() + " " + ext.getDisplayId());
        }
        all.clear();
        all.addAll(Apps.load(this));
        filter("");
    }

    private void filter(String q) {
        String needle = q.trim().toLowerCase(Locale.ROOT);
        shown.clear();
        for (Apps.Entry e : all) {
            if (TextUtils.isEmpty(needle) || e.label.toLowerCase(Locale.ROOT).contains(needle)) {
                shown.add(e);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void open(Apps.Entry e) {
        DeskService s = DeskService.instance;
        if (s != null && s.hasDisplay()) {
            s.launch(e);
        } else {
            Toast.makeText(this, "Служба OppoDesk не включена", Toast.LENGTH_SHORT).show();
        }
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            LinearLayout cell = (LinearLayout) v;
            if (cell == null) {
                cell = new LinearLayout(DesktopActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(4), dp(8), dp(4), dp(8));
                ImageView icon = new ImageView(DesktopActivity.this);
                cell.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));
                TextView label = new TextView(DesktopActivity.this);
                label.setTextColor(Color.WHITE);
                label.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13);
                label.setGravity(Gravity.CENTER);
                label.setMaxLines(2);
                label.setEllipsize(TextUtils.TruncateAt.END);
                label.setPadding(0, dp(6), 0, 0);
                cell.addView(label);
            }
            Apps.Entry e = shown.get(i);
            ((ImageView) cell.getChildAt(0)).setImageDrawable(e.icon);
            ((TextView) cell.getChildAt(1)).setText(e.label);
            return cell;
        }
    }
}
