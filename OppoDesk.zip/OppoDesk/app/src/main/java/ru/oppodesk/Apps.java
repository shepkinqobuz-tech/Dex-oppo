package ru.oppodesk;

import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Список установленных приложений и их запуск на нужном экране. */
final class Apps {
    static final class Entry {
        String label;
        Drawable icon;
        ComponentName component;
    }

    static final String PREFS = "desk";
    static final String KEY_WINDOWED = "windowed";

    /** Последние запущенные приложения — показываются на панели задач. */
    static final List<Entry> recent = new ArrayList<>();
    private static int cascade = 0;

    private Apps() {}

    static List<Entry> load(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<Entry> out = new ArrayList<>();
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            if (ri.activityInfo.packageName.equals(ctx.getPackageName())) continue;
            Entry e = new Entry();
            e.label = String.valueOf(ri.loadLabel(pm));
            e.icon = ri.loadIcon(pm);
            e.component = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            out.add(e);
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    static boolean windowed(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return p.getBoolean(KEY_WINDOWED, true);
    }

    /**
     * Запускает приложение на экране displayId. area — свободная область экрана
     * (без панели задач); если включён оконный режим и прошивка его поддерживает,
     * приложение откроется окном внутри неё, иначе границы будут проигнорированы.
     */
    static void launch(Context ctx, Entry e, int displayId, Rect area) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(e.component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        ActivityOptions o = ActivityOptions.makeBasic();
        o.setLaunchDisplayId(displayId);
        if (area != null && windowed(ctx)) {
            int w = (int) (area.width() * 0.7f), h = (int) (area.height() * 0.8f);
            int step = Math.max(24, area.height() / 30);
            int off = (cascade++ % 5) * step;
            int l = area.left + area.width() / 12 + off, t = area.top + area.height() / 20 + off;
            o.setLaunchBounds(new Rect(l, t, Math.min(l + w, area.right), Math.min(t + h, area.bottom)));
        }
        try {
            ctx.startActivity(i, o.toBundle());
            remember(e);
        } catch (Exception ex) {
            Toast.makeText(ctx, "Не удалось запустить: " + e.label, Toast.LENGTH_SHORT).show();
        }
    }

    private static void remember(Entry e) {
        for (int k = recent.size() - 1; k >= 0; k--) {
            if (recent.get(k).component.equals(e.component)) recent.remove(k);
        }
        recent.add(0, e);
        while (recent.size() > 8) recent.remove(recent.size() - 1);
        DeskService s = DeskService.instance;
        if (s != null) s.refreshRecent();
    }
}
