package ru.oppodesk;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Список установленных приложений и их запуск на внешнем экране. */
final class Apps {
    static final class Entry {
        String label;
        Drawable icon;
        ComponentName component;
    }

    /** Последние запущенные приложения — показываются на панели задач. */
    static final List<Entry> recent = new ArrayList<>();

    private Apps() {}

    static List<Entry> load(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<Entry> out = new ArrayList<>();
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            if (ri.activityInfo.packageName.equals(ctx.getPackageName())) continue;
            Entry e = new Entry();
            e.label = String.valueOf(ri.loadLabel(pm));
            e.icon = ri.loadIcon(pm);
            e.component = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            out.add(e);
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    /**
     * Прошивка не даёт запускать приложения сразу на внешнем экране, поэтому
     * приложение открывается обычным образом, после чего его окно переносится
     * на экран displayId командой оболочки.
     */
    static void launch(Entry e, int displayId) {
        String pkg = e.component.getPackageName();
        String cmp = pkg + "/" + e.component.getClassName();
        String script = "am start -a android.intent.action.MAIN"
                + " -c android.intent.category.LAUNCHER -f 0x10200000 -n '" + cmp + "' >/dev/null;"
                + " t=; for i in 1 2 3 4 5 6 7 8 9 10 11 12; do"
                + " t=$(am stack list | grep -m1 'taskId=[0-9]*: " + pkg + "/'"
                + " | sed 's/.*taskId=\\([0-9]*\\).*/\\1/');"
                + " [ -n \"$t\" ] && break; sleep 0.25; done;"
                + " if [ -n \"$t\" ]; then am display move-stack $t " + displayId + ";"
                + " else echo NOTASK " + pkg + "; fi";
        Sh.run(script);
        remember(e);
    }

    private static void remember(Entry e) {
        for (int k = recent.size() - 1; k >= 0; k--) {
            if (recent.get(k).component.equals(e.component)) recent.remove(k);
        }
        recent.add(0, e);
        while (recent.size() > 8) recent.remove(recent.size() - 1);
        DeskService s = DeskService.instance;
        if (s != null) s.refreshRecent();
    }
}
