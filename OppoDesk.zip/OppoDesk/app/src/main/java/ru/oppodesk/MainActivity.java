package ru.oppodesk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Экран на телефоне: состояние подключения, настройки и тачпад. */
public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status;
    private Button enable;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1117);
        root.setFitsSystemWindows(true);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
        status.setTextIsSelectable(true);
        root.addView(status);

        enable = new Button(this);
        enable.setText("Включить службу OppoDesk");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(enable);

        Button start = new Button(this);
        start.setText("Открыть рабочий стол на мониторе");
        start.setOnClickListener(v -> startDesktop());
        root.addView(start);

        TextView hint = new TextView(this);
        hint.setText("Тачпад: касание — клик, удержание или касание двумя пальцами — "
                + "долгое нажатие, два пальца — прокрутка. Панель задач появляется, "
                + "когда курсор упирается в нижний край монитора");
        hint.setTextColor(0x99FFFFFF);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);
        hint.setPadding(0, dp(8), 0, dp(8));
        root.addView(hint);

        root.addView(new Touchpad(this), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button back = new Button(this);
        back.setText("◀ Назад");
        back.setOnClickListener(v -> { DeskService s = DeskService.instance; if (s != null) s.back(); });
        Button home = new Button(this);
        home.setText("▦ Пуск");
        home.setOnClickListener(v -> startDesktop());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(back, half);
        row.addView(home, half);
        root.addView(row);
        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); handler.post(tick); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(tick); }

    private String error = "";

    private void refresh() {
        DeskService s = DeskService.instance;
        Display ext = DeskService.findExternal(getSystemService(DisplayManager.class));
        StringBuilder sb = new StringBuilder();
        sb.append(ext != null ? "● Монитор подключён: " + ext.getName()
                : "○ Монитор не найден — подключите кабель");
        sb.append('\n');
        if (s == null) sb.append("○ Служба выключена — без неё нет курсора и панели задач");
        else if (s.hasDisplay()) sb.append("● Служба работает, экран ").append(s.displayInfo());
        else sb.append("● Служба включена, ждёт монитор");
        sb.append('\n');
        if (Sh.ready()) sb.append("● Shizuku готов");
        else if (Sh.alive()) sb.append("○ Shizuku запущен, но не дал разрешение — нажмите кнопку ниже");
        else sb.append("○ Shizuku не запущен — откройте его и нажмите «Запуск»");
        if (ext != null) sb.append("\nЭкран №").append(ext.getDisplayId());
        if (!Sh.lastError.isEmpty()) sb.append('\n').append(Sh.lastError);
        if (s != null && !s.lastError.isEmpty()) sb.append('\n').append(s.lastError);
        if (!error.isEmpty()) sb.append('\n').append(error);
        status.setText(sb);
        enable.setVisibility(s == null ? View.VISIBLE : View.GONE);
    }

    private void startDesktop() {
        error = "";
        if (Sh.alive() && !Sh.ready()) {
            Sh.requestPermission();
            return;
        }
        DeskService s = DeskService.instance;
        if (s == null) {
            error = "Сначала включите службу OppoDesk";
        } else {
            s.attach();
            if (s.hasDisplay()) s.showDesktop();
        }
        refresh();
    }

    /** Поверхность тачпада: переводит касания в команды службе. */
    private final class Touchpad extends View {
        private static final float SPEED = 2.2f;
        private final int slop;
        private float lastX, lastY, travelled;
        private int maxPointers;
        private long downAt;

        Touchpad(Context c) {
            super(c);
            slop = ViewConfiguration.get(c).getScaledTouchSlop();
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFF161B22);
            bg.setStroke(dp(1), 0xFF30363D);
            bg.setCornerRadius(dp(16));
            setBackground(bg);
        }

        private float cx(MotionEvent e) {
            float s = 0;
            for (int i = 0; i < e.getPointerCount(); i++) s += e.getX(i);
            return s / e.getPointerCount();
        }

        private float cy(MotionEvent e) {
            float s = 0;
            for (int i = 0; i < e.getPointerCount(); i++) s += e.getY(i);
            return s / e.getPointerCount();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            DeskService s = DeskService.instance;
            if (s == null) return true;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX();
                    lastY = e.getY();
                    travelled = 0;
                    maxPointers = 1;
                    downAt = e.getEventTime();
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    maxPointers = Math.max(maxPointers, e.getPointerCount());
                    lastX = cx(e);
                    lastY = cy(e);
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float nx = cx(e), ny = cy(e);
                    float dx = nx - lastX, dy = ny - lastY;
                    lastX = nx;
                    lastY = ny;
                    travelled += Math.abs(dx) + Math.abs(dy);
                    if (e.getPointerCount() >= 2) s.scroll(dx * SPEED, dy * SPEED);
                    else if (maxPointers == 1) s.moveCursor(dx * SPEED, dy * SPEED);
                    break;
                }
                case MotionEvent.ACTION_POINTER_UP: {
                    // Пересчитываем центр без поднятого пальца, чтобы курсор не прыгал.
                    int up = e.getActionIndex(), n = 0;
                    float sx = 0, sy = 0;
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        if (i == up) continue;
                        sx += e.getX(i);
                        sy += e.getY(i);
                        n++;
                    }
                    if (n > 0) { lastX = sx / n; lastY = sy / n; }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (travelled < slop * 2) {
                        long held = e.getEventTime() - downAt;
                        if (maxPointers >= 2 || held >= 450) s.longClick();
                        else s.click();
                    }
                    break;
            }
            return true;
        }
    }
}
